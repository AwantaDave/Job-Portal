<?php
session_start();
include_once('../config.php');
$empid=$_GET['id'];
$query=mysqli_query($db1,"select * from employer where eid = $empid");
$result=mysqli_fetch_array($query);
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Employer</title>
</head>
<div id="nav">
    <nav>
        <div class="navbar" id="insidenav">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Job Portal</a>
            </div>
            <ul class="nav navbar-nav">
                <li ><a href="profile.php"><?php echo "$_SESSION[jsname]"; ?><span class="sr-only">(current)</span></a></li>
                <li><a href="#">Notifications</a></li>
                <li class="active"><a href="#"> View Employer </a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Options<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Update Profile</a></li>
                        <li><a href="#">View Applied Jobs</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">View Selected Jobs</a></li>
                    </ul>
                </li>
            </ul>
            <form class="navbar-form navbar-left" role="search" method="get" action="search.php">
                <div class="form-group">
                    <input type="text" name="keyword" class="form-control" placeholder="Search Jobs">
                </div>
                <button type="submit" class="btn btn-default">Search</button>
            </form>
            <ul class="nav navbar-nav navbar-right">
                
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</div><!-- /.container-fluid -->
<body>

<!-- left side info and logo  -->
 <aside class="col-sm-3 text-center" role="complementary">
        <div class="thumbnail text-center">
            <?php if($result['logo']!="") {
                echo "<img src = '../uploads/logo/".$result['logo']."' class='img-rounded' >";
            }else echo" <img src='../images/fallbacklogo.jpg'>";
            ?>
            <strong><?php echo $result['ename']; ?></strong><br> <br>
            </strong> &nbsp;&nbsp;
            <a class="btn btn-success btn-block" href="jobs_by_emp.php?eid=<?php echo $empid; ?>&ename=<?php echo $result['ename']; ?>"
             style="font-size: 16px";> View All jobs of <?php echo $result['ename']; ?> </a>
        </div>
    </aside>
<!-- left side info ends here  -->

<!-- right side section - starts here - -->
<section class="col-sm-9">
<div class="container" style="margin-top: 30px;" id="tablecontent">

    <h2 style="text-align:center">Employer: <?php echo $result['ename']; ?></h2>
    <div class='page-header' style='background: #6969'></div>

<table class="table table-responsive">
    <tr>
        <td class="tbold">Employer Name:</td>
        <td><strong><?php echo $result['ename']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Employer Type:</td>
        <td><?php echo $result['etype']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Industry:</td>
        <td><?php echo $result['industry']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Address:</td>
        <td><?php echo $result['address']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Pincode:</td>
        <td><?php echo $result['pincode']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Executive Name:</td>
        <td><?php echo $result['executive']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Phone Number:</td>
        <td><?php echo $result['phone']; ?></td>
    </tr>
    <tr>
        <td class="tbold">Main Location:</td>
        <td><?php echo $result['location']; ?></td>
    </tr>
    <tr>
        <td class="tbold">About Company:</td>
        <td><?php echo $result['profile']; ?></td>
    </tr>
</table>


</div>
</div> <!-- container -->
</body>
<link rel="stylesheet" href="../bootstrap/dist/css/bootstrap.min.css">
<link href="../css/main.css" rel="stylesheet">
<link href="../css/jobseeker.css" rel="stylesheet">
<script src="../js/jquery-1.12.0.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</html>
